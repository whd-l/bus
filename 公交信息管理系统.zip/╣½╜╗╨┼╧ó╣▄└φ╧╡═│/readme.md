<div style="text-align: center;">
    <span style="font-size: 40px; font-weight: bold;">公交安全管理系统</span>
</div>
---

# 需求分析

## 数据库的有关语义

1. 公交公司有若干个车队，每个车队下有若干条线路；
2. 公交公司有若干辆汽车，每辆车属于一条线路；
3. 每个车队有一名队长，他只有管理工作，不开车；
4. 每条线路有若干名司机，其中有一名路队长，除开车外，还承担管理工作；每名司机只在一条线路上开车；
5. 司机开车时会产生违章，包含：闯红灯、未礼让斑马线、压线、违章停车等；
6. 队长、路队长负责将司机的违章信息输入到系统，包含：司机、车辆、车队、线路、站点、时间、违章等。

## 前台程序
开发一个公交安全管理系统来对数据库进行访问，可以使用Java、Python、C等集成开发环境。
系统实现功能如下：

1. 录入司机基本信息，如工号、姓名、性别等；
2. 录入汽车基本信息，如车牌号、座数等；
3. 录入司机的违章信息；
4. 查询某个车队下的司机基本信息；
5. 查询某名司机在某个时间段的违章详细信息；
6. 查询某个车队在某个时间段的违章统计信息，如：2次闯红灯、4次未礼让斑马线等。

# 概念结构设计

根据数据库的有关语义设计E-R图如下：

<img src="./image-20231220193403247.png" alt="image-20231220193403247" style="zoom:50%;" />

# 逻辑结构设计

考虑到在数据库的设计过程中需要避免出现插入异常、删除异常、数据冗余等问题，将E-R图转换为关系模型

| 名称 |                             属性                             |
| :--: | :----------------------------------------------------------: |
| 车队 |                  （车队号ID，车队长员工ID）                  |
| 路线 |              （路线号，路队长员工ID，车队号ID）              |
| 汽车 | （车牌号，座位数量，所属车队ID，所属路线ID，所属司机员工ID） |
| 违章 |      （违章ID，违章类型，违章时间，司机员工ID，车牌号）      |
| 员工 |              （员工ID，姓名，性别，年龄，职位）              |

# 程序开发环境及应用环境

## RDBM

使用MySQL作为本次实验的开源关系型数据库管理系统（RDBMS），于是定义了五张表，分别为：

<img src="./image-20231220193712367.png" alt="image-20231220193712367" style="zoom:80%;" />

###  employ表

```mysql
create table employee(
	id int(10) unsigned primary key auto_increment,
	employee_id char(4) not null comment '员工ID',
	name char(5) not null comment '姓名',
    gender enum('男','女') not null comment '性别',
    age tinyint(3) unsigned not null comment '年龄',
    position enum('司机','路线队长') not null comment '职位' 
);
```

<img src="./image-20231220194434788.png" alt="image-20231220194434788" style="zoom:80%;" />

年龄使用tinyint(3) unsigned类型；

性别和职位使用enum类型。

<img src="./image-20231220194439827.png" alt="image-20231220194439827" style="zoom:80%;" />

员工序列号不能重复使用。

### fleet表

``` mysql
create table fleet(
	fleet_id tinyint(3) unsigned primary key comment '车队ID',
	captain_id char(4) not null
);
```

<img src="./image-20231220194549623.png" alt="image-20231220194549623" style="zoom:80%;" />

### path表

``` mysql
create table path(
    path_id tinyint(3) unsigned primary key auto_increment,
    captain_id char(4) not null comment '路线队长员工ID',
    fleet_id tinyint(3) unsigned not null comment '车队ID'
);
```

<img src="./image-20231220194622073.png" alt="image-20231220194622073" style="zoom:80%;" />

### peccancy表

``` mysql
create table peccancy(
    id int(10) primary key auto_increment not null,
    type enum('闯红灯','未礼让斑马线','压线','违章停车','超速'),
    time datetime not null comment '违章时间',
    driver_id char(4) not null,
    license char(5) not null
);
```

<img src="./image-20231220194700084.png" alt="image-20231220194700084" style="zoom:80%;" />

违章类型使用`enum('闯红灯','未礼让斑马线','压线','违章停车','超速')`类型。

### vehicle表

``` mysql
create table vehicle(
	id int(10) unsigned primary key auto_increment comment '车辆记录id号',
    license char(5) not null comment '车牌号',
    seating tinyint(3) comment '座位数量',
    fleet_id tinyint(3) comment '车队ID',
   	path_id tinyint(3) comment '路线ID',
    driver_id char(4) comment '司机ID'
);
```

<img src="./image-20231220194839610.png" alt="image-20231220194839610" style="zoom:80%;" />

<img src="./image-20231220194732342.png" alt="image-20231220194732342" style="zoom:80%;" />

车牌号、司机员工号均为唯一键。

## 视图

使用视图来简化系统的设计。

### 车队1的司机基本信息

``` mysql
select `employee`.`employee_id` AS `employee_id`,`employee`.`name` AS `NAME`,`employee`.`gender` AS `gender`,`employee`.`age` AS `age`,`vehicle`.`path_id` AS `path_id`,`vehicle`.`license` AS `license`,`employee`.`position` AS `position` from (`employee` join `vehicle` on(((`employee`.`employee_id` = `vehicle`.`driver_id`) and (`vehicle`.`fleet_id` = 1)))) order by `employee`.`employee_id`
```

<img src="./image-20231220195925005.png" alt="image-20231220195925005" style="zoom:50%;" />

### 车队2的司机基本信息

``` mysql
select `employee`.`employee_id` AS `employee_id`,`employee`.`name` AS `NAME`,`employee`.`gender` AS `gender`,`employee`.`age` AS `age`,`vehicle`.`path_id` AS `path_id`,`vehicle`.`license` AS `license`,`employee`.`position` AS `position` from (`employee` join `vehicle` on(((`employee`.`employee_id` = `vehicle`.`driver_id`) and (`vehicle`.`fleet_id` = 2)))) order by `employee`.`employee_id`
```

<img src="./image-20231220200025818.png" alt="image-20231220200025818" style="zoom:50%;" />

### 车队1的违章信息

``` mysql
select `peccancy`.`time` AS `time`,`peccancy`.`type` AS `type`,`peccancy`.`driver_id` AS `driver_id`,`peccancy`.`license` AS `license`,`vehicle`.`path_id` AS `path_id` from (`peccancy` join `vehicle` on(((`peccancy`.`driver_id` = `vehicle`.`driver_id`) and (`vehicle`.`fleet_id` = 1))))
```

<img src="./image-20231220200131421.png" alt="image-20231220200131421" style="zoom:50%;" />

### 车队1的违章信息

``` mysql
select `peccancy`.`time` AS `time`,`peccancy`.`type` AS `type`,`peccancy`.`driver_id` AS `driver_id`,`peccancy`.`license` AS `license`,`vehicle`.`path_id` AS `path_id` from (`peccancy` join `vehicle` on(((`peccancy`.`driver_id` = `vehicle`.`driver_id`) and (`vehicle`.`fleet_id` = 2))))
```

<img src="./image-20231220200238450.png" alt="image-20231220200238450" style="zoom:50%;" />

## 前台程序

使用Java集成开发环境。

创建了三个java文件：

1. Run运行
2. Service负责连接MySQL数据库、逻辑代码处理
3. View用户视图

<img src="./image-20231220200406919.png" alt="image-20231220200406919" style="zoom:80%;" />

## View

<img src="./image-20231220201040633.png" alt="image-20231220201040633" style="zoom:80%;" />

## Service

<img src="./image-20231220201158597.png" alt="image-20231220201158597" style="zoom:80%;" />

# 应用程序设计中遇到的问题及解决方法

## java连接数据库

最开始连接时反复报错，通过搜索error号、查阅相关文章发现需要设置`useSSL=false`才能信任连接。

<img src="./image-20231220201728540.png" alt="image-20231220201728540" style="zoom:80%;" />

# 总结

经过本次实验，我们成功设计并实现了公交安全管理系统，通过Java前台程序和Mysql数据库的配合，实现司机信息录入、违章记录和查询功能。该系统可以有效地帮助公交公司管理车队和司机信息，提高公交安全管理的效率和准确性。同时，我们也对数据库的优化和索引的使用做了相应的工作，提高了系统的查询效率和响应速度。

本次实验让我们深刻认识到了数据库设计和开发的重要性，也使我们更加熟练地掌握了Java开发和Mysql数据库的使用。