INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0007', '陈建国', '男', 46, 3, '2233', '司机');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0009', '岳云鹏', '男', 47, 3, '2263', '司机');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0011', '赵希希', '女', 35, 4, '1001', '司机');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0014', '刘楠', '男', 46, 4, '7799', '司机');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0015', '林琳', '女', 49, 3, '6677', '路线队长');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0016', '王巴克', '男', 30, 4, '6600', '路线队长');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0017', '李然', '男', 41, 4, '1119', '司机');
INSERT INTO `vw_driver_f2` (`employee_id`, `NAME`, `gender`, `age`, `path_id`, `license`, `position`) VALUES ('0018', '刘翔光', '男', 29, 4, '2229', '司机');
