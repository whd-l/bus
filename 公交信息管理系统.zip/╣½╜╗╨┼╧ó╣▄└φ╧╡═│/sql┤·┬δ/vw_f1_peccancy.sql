INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-10 11:42:32', '闯红灯', '0003', '1235', 2);
INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-03 12:44:00', '压线', '0004', '1225', 1);
INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-11 12:42:30', '超速', '0002', '1234', 1);
INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-02 00:00:00', '压线', '0002', '1234', 1);
INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-08 00:00:00', '闯红灯', '0003', '1235', 2);
INSERT INTO `vw_f1_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-12-12 00:00:00', '压线', '0021', '0003', 1);
