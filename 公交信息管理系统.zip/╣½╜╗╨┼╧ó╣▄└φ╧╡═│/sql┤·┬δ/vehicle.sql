/*
 Navicat Premium Data Transfer

 Source Server         : local_school
 Source Server Type    : MySQL
 Source Server Version : 50743
 Source Host           : localhost:3306
 Source Schema         : bus

 Target Server Type    : MySQL
 Target Server Version : 50743
 File Encoding         : 65001

 Date: 29/12/2023 15:30:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for vehicle
-- ----------------------------
DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE `vehicle`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '车辆记录id号',
  `license` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '车牌号',
  `seating` tinyint(3) UNSIGNED NULL DEFAULT NULL COMMENT '座位数量',
  `fleet_id` tinyint(3) UNSIGNED NOT NULL COMMENT '车队ID',
  `path_id` tinyint(3) UNSIGNED NOT NULL COMMENT '路线ID',
  `driver_id` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '司机ID',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `license`(`license`) USING BTREE,
  UNIQUE INDEX `driver_id`(`driver_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vehicle
-- ----------------------------
INSERT INTO `vehicle` VALUES (1, '1234', 20, 1, 1, '0002');
INSERT INTO `vehicle` VALUES (2, '1235', 20, 1, 2, '0003');
INSERT INTO `vehicle` VALUES (4, '1225', 40, 1, 1, '0004');
INSERT INTO `vehicle` VALUES (6, '2235', 20, 1, 2, '0006');
INSERT INTO `vehicle` VALUES (7, '2233', 30, 2, 3, '0007');
INSERT INTO `vehicle` VALUES (8, '2263', 20, 2, 3, '0009');
INSERT INTO `vehicle` VALUES (9, '7777', 30, 1, 1, '0010');
INSERT INTO `vehicle` VALUES (10, '7797', 20, 1, 1, '0013');
INSERT INTO `vehicle` VALUES (11, '7799', 20, 2, 4, '0014');
INSERT INTO `vehicle` VALUES (12, '1119', 40, 2, 4, '0017');
INSERT INTO `vehicle` VALUES (13, '2229', 20, 2, 4, '0018');
INSERT INTO `vehicle` VALUES (15, '6666', 20, 1, 2, '0008');
INSERT INTO `vehicle` VALUES (16, '6677', 20, 2, 3, '0015');
INSERT INTO `vehicle` VALUES (17, '6600', 20, 2, 4, '0016');
INSERT INTO `vehicle` VALUES (18, '1001', 15, 2, 4, '0011');
INSERT INTO `vehicle` VALUES (19, '9999', 30, 1, 1, '0005');
INSERT INTO `vehicle` VALUES (21, '0010', 30, 1, 2, '0020');
INSERT INTO `vehicle` VALUES (22, '0003', 20, 1, 1, '0021');

SET FOREIGN_KEY_CHECKS = 1;
