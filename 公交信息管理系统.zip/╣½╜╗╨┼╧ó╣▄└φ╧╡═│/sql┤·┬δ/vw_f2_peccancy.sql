INSERT INTO `vw_f2_peccancy` (`time`, `type`, `driver_id`, `license`, `path_id`) VALUES ('2023-11-23 03:44:31', '违章停车', '0011', '0014', 4);
