/*
 Navicat Premium Data Transfer

 Source Server         : local_school
 Source Server Type    : MySQL
 Source Server Version : 50743
 Source Host           : localhost:3306
 Source Schema         : bus

 Target Server Type    : MySQL
 Target Server Version : 50743
 File Encoding         : 65001

 Date: 29/12/2023 15:30:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for peccancy
-- ----------------------------
DROP TABLE IF EXISTS `peccancy`;
CREATE TABLE `peccancy`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '违章序列ID',
  `type` enum('闯红灯','未礼让斑马线','压线','违章停车','超速') CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `time` datetime NOT NULL COMMENT '违章时间',
  `driver_id` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `license` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of peccancy
-- ----------------------------
INSERT INTO `peccancy` VALUES (1, '闯红灯', '2023-11-10 11:42:32', '0003', '1235');
INSERT INTO `peccancy` VALUES (2, '压线', '2023-11-03 12:44:00', '0004', '1225');
INSERT INTO `peccancy` VALUES (3, '违章停车', '2023-11-23 03:44:31', '0011', '0014');
INSERT INTO `peccancy` VALUES (4, '超速', '2023-11-11 12:42:30', '0002', '1234');
INSERT INTO `peccancy` VALUES (11, '压线', '2023-11-02 00:00:00', '0002', '1234');
INSERT INTO `peccancy` VALUES (12, '闯红灯', '2023-11-08 00:00:00', '0003', '1235');
INSERT INTO `peccancy` VALUES (13, '压线', '2023-12-12 00:00:00', '0021', '0003');

SET FOREIGN_KEY_CHECKS = 1;
