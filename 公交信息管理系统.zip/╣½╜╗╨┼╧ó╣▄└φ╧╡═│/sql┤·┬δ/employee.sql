/*
 Navicat Premium Data Transfer

 Source Server         : local_school
 Source Server Type    : MySQL
 Source Server Version : 50743
 Source Host           : localhost:3306
 Source Schema         : bus

 Target Server Type    : MySQL
 Target Server Version : 50743
 File Encoding         : 65001

 Date: 29/12/2023 15:28:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for employee
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '员工ID',
  `name` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '姓名',
  `gender` enum('男','女') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '性别',
  `age` tinyint(3) UNSIGNED NOT NULL COMMENT '年龄',
  `position` enum('车队队长','路线队长','司机') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '职位',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `employ_id`(`employee_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES (1, '0001', '李华', '男', 30, '车队队长');
INSERT INTO `employee` VALUES (2, '0002', '王华话', '女', 44, '司机');
INSERT INTO `employee` VALUES (3, '0003', '李明明', '男', 33, '司机');
INSERT INTO `employee` VALUES (4, '0004', '王五', '男', 20, '司机');
INSERT INTO `employee` VALUES (5, '0005', '刘代表', '男', 25, '路线队长');
INSERT INTO `employee` VALUES (6, '0006', '王三', '男', 26, '司机');
INSERT INTO `employee` VALUES (7, '0007', '陈建国', '男', 46, '司机');
INSERT INTO `employee` VALUES (8, '0008', '李建滨', '男', 28, '路线队长');
INSERT INTO `employee` VALUES (10, '0009', '岳云鹏', '男', 47, '司机');
INSERT INTO `employee` VALUES (11, '0010', '赵东', '女', 67, '司机');
INSERT INTO `employee` VALUES (12, '0011', '赵希希', '女', 35, '司机');
INSERT INTO `employee` VALUES (13, '0012', '刘伟高', '男', 34, '车队队长');
INSERT INTO `employee` VALUES (14, '0013', '韩光光', '男', 44, '司机');
INSERT INTO `employee` VALUES (15, '0014', '刘楠', '男', 46, '司机');
INSERT INTO `employee` VALUES (16, '0015', '林琳', '女', 49, '路线队长');
INSERT INTO `employee` VALUES (17, '0016', '王巴克', '男', 30, '路线队长');
INSERT INTO `employee` VALUES (18, '0017', '李然', '男', 41, '司机');
INSERT INTO `employee` VALUES (19, '0018', '刘翔光', '男', 29, '司机');
INSERT INTO `employee` VALUES (26, '0020', '里哈', '男', 28, '司机');
INSERT INTO `employee` VALUES (28, '0021', '李华', '男', 23, '司机');

SET FOREIGN_KEY_CHECKS = 1;
