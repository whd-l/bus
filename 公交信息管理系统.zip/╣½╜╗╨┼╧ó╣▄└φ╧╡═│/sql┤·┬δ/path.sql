/*
 Navicat Premium Data Transfer

 Source Server         : local_school
 Source Server Type    : MySQL
 Source Server Version : 50743
 Source Host           : localhost:3306
 Source Schema         : bus

 Target Server Type    : MySQL
 Target Server Version : 50743
 File Encoding         : 65001

 Date: 29/12/2023 15:30:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for path
-- ----------------------------
DROP TABLE IF EXISTS `path`;
CREATE TABLE `path`  (
  `path_id` tinyint(3) UNSIGNED NOT NULL,
  `captain_id` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '路线队长员工ID',
  `fleet_id` tinyint(3) UNSIGNED NOT NULL COMMENT '车队ID',
  PRIMARY KEY (`path_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of path
-- ----------------------------
INSERT INTO `path` VALUES (1, '0005', 1);
INSERT INTO `path` VALUES (2, '0008', 1);
INSERT INTO `path` VALUES (3, '0015', 2);
INSERT INTO `path` VALUES (4, '0016', 2);

SET FOREIGN_KEY_CHECKS = 1;
