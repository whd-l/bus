import java.sql.SQLException;
import java.util.Scanner;

public class View {
    private Service service;
    private final static Scanner sc = new Scanner(System.in);//输入
    private static boolean isContinue = true;//是否退出


    /**
     * 录入司机基本信息
     */
    private void registerDriver() throws SQLException {
        String name, id, gender, age, post;
        System.out.println("========================================");
        System.out.println("请输入司机基本信息：");
        System.out.println("姓名：");
        name = sc.next();
        System.out.println("工号ID：");
        id = sc.next();
        System.out.println("性别（男/女）：");
        gender = sc.next();
        System.out.println("年龄：");
        age = sc.next();
        System.out.println("职位（路线队长/司机）：");
        post = sc.next();
        if (!service.registerDriver(name, id, gender, age, post)) {
            System.out.println("录入失败，请检查：");
            System.out.println("1.工号是否重复");
            System.out.println("2.其他数据格式问题");
            return;
        }
        System.out.println("工号为：" + id + "的司机基本信息录入成功！");
    }

    /**
     * 录入汽车基本信息
     */
    private void registerBus() throws SQLException {
        String license, seating, fleet_id, path_id, driver_id;
        System.out.println("=============================================");
        System.out.println("请输入公交车基本信息：");
        System.out.println("车牌号：");
        license = sc.next();
        System.out.println("座位数：");
        seating = sc.next();
        System.out.println("司机工号ID：");
        driver_id = sc.next();
        System.out.println("所属车队（1/2）：");
        fleet_id = sc.next();
        System.out.println("所属路线：");
        path_id = sc.next();

        if (!service.registerBus(license, seating, fleet_id, path_id, driver_id)) {
            System.out.println("录入失败，请检查：");
            System.out.println("1.车牌号是否已存在");
            System.out.println("2.司机工号是否正确，司机是否已驾驶其他公交车");
            System.out.println("3.车队号和路线号对应关系不正确");
            System.out.println("4.其他数据格式问题");
            return;
        }
        System.out.println("车牌号为：" + license + "的公交车基本信息录入成功！");
    }

    /**
     * 录入司机违章信息
     */
    private void enterPeccancy() throws SQLException {
        String type, time, driver_id, license;
        System.out.println("================================================");
        System.out.println("请输入违章信息：");
        System.out.println("违章类型（闯红灯/未礼让斑马线/压线/违章停车/超速）：");
        type = sc.next();
        System.out.println("违章时间（yyyy-mm-dd hh:mm:ss）：");
        time = sc.next();
        System.out.println("车牌号：");
        license = new Scanner(System.in).next();
        System.out.println("司机工号：");
        driver_id = new Scanner(System.in).next();

        if (!service.enterPeccancy(type, time, driver_id, license)) {
            System.out.println("录入失败，请检查：");
            System.out.println("1.车牌号和司机工号是否都存在且对应正确");
            System.out.println("2.其他数据格式问题");
            return;
        }
        System.out.println("该违章信息录入成功！");
    }

    /**
     * 查询某个车队下的司机的基本信息
     */
    private void showDriverInFleet() throws SQLException {
        System.out.println("======================================");
        System.out.println("请输入您所要查询的车队（1/2）：");
        String choice = sc.next();
        if (!(choice.equals("1") || choice.equals("2"))) {
            System.out.println("输入格式不正确。");
            return;
        }
        service.showDriverInFleet(choice);
    }

    /**
     * 查询某个司机在某段时间内的违章详细信息
     */
    private void showDriverPeccancy() throws SQLException {
        String id, begin, end;
        System.out.println("============================================================");
        System.out.println("请输入您所要查询的司机工号ID：");
        id = sc.next();
        System.out.println("请输入您所要查询的违章开始时间（yyyy-mm-dd(hh-mm-ss)/default）：");
        begin = sc.next();
        System.out.println("请输入您所要查询的违章截止时间（yyyy-mm-dd(hh-mm-ss)/default）：");
        end = sc.next();
        if (!service.showDriverPeccancy(id, begin, end)) {
            System.out.println("您输入的格式有误，将显示该司机所有违规记录：");
            service.showDriverPeccancy(id);
        }
    }

    /**
     * 查询某个车队在某个时间段的违章统计信息
     */
    private void showFleetPeccancy() throws SQLException {
        String choice, begin, end;
        System.out.println("============================================");
        System.out.println("请输入您所要查询的车队（1/2）：");
        choice = sc.next();
        System.out.println("请输入您所要查询的违章开始时间（yyyy-mm-dd(hh-mm-ss)/default）：");
        begin = sc.next();
        System.out.println("请输入您所要查询的违章截止时间（yyyy-mm-dd(hh-mm-ss)/default）：");
        end = sc.next();
        if (!service.showFleetPeccancy(choice, begin, end)) {
            System.out.println("您输入的格式有误，将显示该车队所有违规记录：");
            service.showFleetPeccancy(choice);
        }

    }

    /**
     * 主界面
     */
    private void mainView() throws SQLException {
        System.out.println("=============================================");
        System.out.println("1.录入司机基本信息");
        System.out.println("2.录入汽车基本信息");
        System.out.println("3.录入司机违章信息");
        System.out.println("4.查询某个车队下的司机的基本信息");
        System.out.println("5.查询某个司机在某段时间内的违章详细信息");
        System.out.println("6.查询某个车队在某个时间段的违章统计信息");
        System.out.println("7.退出");
        System.out.println("---------------------------------------");
        System.out.println("请输入您想选择的功能(1-7)：");
        switch (sc.next()) {
            case "1":
                registerDriver();
                break;
            case "2":
                registerBus();
                break;
            case "3":
                enterPeccancy();
                break;
            case "4":
                showDriverInFleet();
                break;
            case "5":
                showDriverPeccancy();
                break;
            case "6":
                showFleetPeccancy();
                break;
            case "7":
                isContinue = false;
                System.out.println("感谢使用，再会。");
                break;
            default:
                System.out.println("输入格式不正确。");
        }
    }

    public void run() throws SQLException {
        System.out.println("本软件查询设计隐私，使用前请输入密码：");
        String input = sc.next();
        if (!input.equals(service.getPass())) {
            System.out.println("密码输入失败，程序将自动退出。");
            return;
        }
        System.out.println("密码正确，请使用：");
        while (isContinue) {
            mainView();
        }
    }

    public View() throws SQLException, ClassNotFoundException {
        service = new Service();
    }
}
