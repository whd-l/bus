import java.sql.*;

public class Service {
    private String pass = "654321";
    private Statement statement;
    ResultSet resultSet;
    private String sql;

    public boolean registerDriver(String name, String id, String gender, String age, String post) throws SQLException {
        Boolean success = false;

        //检查职位post数据格式
        if (post.equals("车队队长")) {
            return false;
        }
        //插入数据
        sql = "INSERT INTO employee values (null,'%s','%s','%s',%s,'%s')";
        String sql2 = String.format(sql, id, name, gender, age, post);
        try {
            success = statement.executeUpdate(sql2) == 1;
        } catch (Exception e) {

        }

        return success;
    }

    public boolean registerBus(String license, String seating, String fleet_id, String path_id, String driver_id) throws SQLException {
        boolean success = false;
        //判断driver_id是否存在
        sql = "SELECT * FROM employee WHERE employee_id = '" + driver_id + "'";
        resultSet = statement.executeQuery(sql);
        if (!resultSet.next()) {
            return false;
        }
        //fleet_id和path_id要匹配
        if ((fleet_id.equals("2") && (path_id.equals("3") || path_id.equals("4"))) || (fleet_id.equals("1") && (path_id.equals("2") || path_id.equals("1")))) {
            success = true;
        }
        //如果fleet_id和path_id不匹配，则返回false
        if (!success) {
            return false;
        }
        success = false;
        //开始插入
        sql = "INSERT INTO vehicle VALUES (NULL,'%s',%s,%s,%s,'%s')";
        String sql2 = String.format(sql, license, seating, fleet_id, path_id, driver_id);
        try {
            success = statement.executeUpdate(sql2) == 1;
        } catch (Exception e) {

        }
        return success;
    }

    public boolean enterPeccancy(String type, String time, String driver_id, String license) throws SQLException {
        boolean success = false;

        //查看license和driver_id是否匹配
        sql = "SELECT * FROM vehicle where license = '" + license + "' AND driver_id = '" + driver_id + "';";
        resultSet = statement.executeQuery(sql);
        if (!resultSet.next()) {//不匹配
            return false;
        }

        //插入数据
        sql = "INSERT INTO peccancy VALUES (NULL,'%s','%s','%s','%s')";
        String sql2 = String.format(sql, type, time, driver_id, license);
        try {
            success = statement.executeUpdate(sql2) == 1;
        } catch (Exception e) {

        }
        return success;
    }

    public void showDriverInFleet(String choice) throws SQLException {
        sql = "SELECT * FROM vw_driver_f" + choice;
        resultSet = statement.executeQuery(sql);
        System.out.println("员工号\t姓名\t性别 年龄 驾驶路线\t驾驶车牌号\t职位");
        while (resultSet.next()) {
            System.out.println(resultSet.getString("employee_id") + "\t" +
                    resultSet.getString("name") + "\t" +
                    resultSet.getString("gender") + "\t" +
                    resultSet.getString("age") + "\t" + "\t" +
                    resultSet.getString("path_id") + "\t" + "\t" +
                    resultSet.getString("license") + "\t" + "\t" +
                    resultSet.getString("position"));
        }
    }

    public boolean showDriverPeccancy(String id, String begin, String end) throws SQLException {
        if (begin.equals("default") && end.equals("default")) {
            return showDriverPeccancy(id);
        }
        sql = "SELECT * FROM peccancy WHERE time >= '" + begin + "' AND time <='" + end + "' AND driver_id = '" + id + "'";
        return driverPeccancySearch();
    }

    private boolean driverPeccancySearch() throws SQLException {
        boolean success = true;
        resultSet = statement.executeQuery(sql);
        try {
            System.out.println("时间\t\t\t\t\t违规内容\t\t司机工号\t车牌号");
            while (resultSet.next()) {
                System.out.println(resultSet.getString("time") + "\t" +
                        resultSet.getString("type") + "\t\t" +
                        resultSet.getString("driver_id") + "\t" +
                        resultSet.getString("license") + "\t");
            }
        } catch (Exception e) {
            success = false;
        }
        return success;
    }

    public boolean showDriverPeccancy(String id) throws SQLException {
        sql = "SELECT * FROM peccancy WHERE  driver_id = '" + id + "'";
        return driverPeccancySearch();
    }

    public boolean showFleetPeccancy(String choice) throws SQLException {
        sql = "SELECT * FROM vw_f" + choice + "_peccancy";
        String sql2 = "SELECT type,COUNT(type) FROM vw_f" + choice + "_peccancy GROUP BY type";
        return fleetPeccancySearch(sql2);
    }

    private boolean fleetPeccancySearch(String sql2) throws SQLException {
        boolean success = true;
        try {
            resultSet = statement.executeQuery(sql);
            System.out.println("时间\t\t\t\t\t违规内容\t\t司机工号\t车牌号\t路线");
            while (resultSet.next()) {
                System.out.println(resultSet.getString("time") + "\t" +
                        resultSet.getString("type") + "\t\t" +
                        resultSet.getString("driver_id") + "\t" +
                        resultSet.getString("license") + "\t" +
                        resultSet.getString("path_id") + "\t");
            }
            System.out.println("总计：");
            resultSet = statement.executeQuery(sql2);
            System.out.println("违规内容\t次数");
            while (resultSet.next()) {
                System.out.println(resultSet.getString("type") + "\t" +
                        resultSet.getString("COUNT(type)"));
            }

        } catch (Exception e) {
            success = false;
        }
        return success;
    }

    public boolean showFleetPeccancy(String choice, String begin, String end) throws SQLException {
        if (begin.equals("default") && end.equals("default")) {
            return showFleetPeccancy(choice);
        }
        sql = "SELECT * FROM vw_f" + choice + "_peccancy WHERE time BETWEEN '" + begin + "' AND '" + end + "'";
        String sql2 = "SELECT type,COUNT(type) FROM vw_f" + choice + "_peccancy WHERE time BETWEEN '" + begin + "' AND '" + end + "'" +
                "GROUP BY type";
        return fleetPeccancySearch(sql2);
    }

    public Service() throws ClassNotFoundException, SQLException {
        //加载驱动6
        Class.forName("com.mysql.jdbc.Driver");
        //连接数据库
        String url = "jdbc:mysql://localhost:3306/bus" +
                "?useSSL=false&useUnicode=true&characterEncoding=utf8&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        String name = "root";
        String pwd = "654321";
        Connection connection = DriverManager.getConnection(url, name, pwd);
        if (connection == null) {
            System.out.println("数据库连接失败。");
        }
        statement = connection.createStatement();
    }


    public String getPass() {
        return pass;
    }


}
